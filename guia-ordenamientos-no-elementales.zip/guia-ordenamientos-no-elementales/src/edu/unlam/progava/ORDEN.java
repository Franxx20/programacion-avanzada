package edu.unlam.progava;

public enum ORDEN {
    INVERSO, ALEATORIO, ORDENADO
}
