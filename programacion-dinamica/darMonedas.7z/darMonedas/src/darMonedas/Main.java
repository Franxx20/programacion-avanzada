package darMonedas;

public class Main {

	public static void main(String[] args) {

		int[] monedas = { 2, 3, 7 };
		int dinero = 15;

		Monedas moneda = new Monedas(dinero, monedas);
		// TODO Auto-generated method stub
		moneda.buscar(monedas, dinero);

	}

}
